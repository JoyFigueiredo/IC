public abstract class RNA {
    public abstract double[] treinar(double [] Xin, double[] y);
    public abstract double[] executar(double [] Xin);
}
