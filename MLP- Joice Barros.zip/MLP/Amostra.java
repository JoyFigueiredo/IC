public class Amostra {
    static int qtdIn=3, qtdOut=2, amostra= 8;
    double[] X;
    double[] Y;

    public Amostra() {
        this.X = new double[qtdIn];
        this.Y = new double[qtdOut];
    }
}